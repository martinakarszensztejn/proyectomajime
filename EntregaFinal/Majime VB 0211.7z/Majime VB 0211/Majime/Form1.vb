﻿
Public Class Form1






    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Guau.AbrirFormEnPanel(New Form3)
    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        Guau.AbrirFormEnPanel(New Form2)
    End Sub


End Class
