﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainOficinista
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainOficinista))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Button12A = New System.Windows.Forms.Button()
        Me.btnFoto1 = New System.Windows.Forms.Button()
        Me.Button10A = New System.Windows.Forms.Button()
        Me.Button9A = New System.Windows.Forms.Button()
        Me.Button7A = New System.Windows.Forms.Button()
        Me.Button8A = New System.Windows.Forms.Button()
        Me.Button6A = New System.Windows.Forms.Button()
        Me.Button5A = New System.Windows.Forms.Button()
        Me.Button4A = New System.Windows.Forms.Button()
        Me.Button3A = New System.Windows.Forms.Button()
        Me.Button2A = New System.Windows.Forms.Button()
        Me.Button1A = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.Image = Global.Majime.My.Resources.Resources.logou
        Me.PictureBox1.Location = New System.Drawing.Point(12, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(175, 94)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 52
        Me.PictureBox1.TabStop = False
        '
        'Button12A
        '
        Me.Button12A.Image = Global.Majime.My.Resources.Resources.add1
        Me.Button12A.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button12A.Location = New System.Drawing.Point(347, 289)
        Me.Button12A.Name = "Button12A"
        Me.Button12A.Size = New System.Drawing.Size(120, 30)
        Me.Button12A.TabIndex = 50
        Me.Button12A.Text = "Agregar Vehículos"
        Me.Button12A.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button12A.UseVisualStyleBackColor = True
        '
        'btnFoto1
        '
        Me.btnFoto1.Image = Global.Majime.My.Resources.Resources.camera_add
        Me.btnFoto1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnFoto1.Location = New System.Drawing.Point(473, 160)
        Me.btnFoto1.Name = "btnFoto1"
        Me.btnFoto1.Size = New System.Drawing.Size(120, 31)
        Me.btnFoto1.TabIndex = 47
        Me.btnFoto1.Text = "Agregar Fotos"
        Me.btnFoto1.UseVisualStyleBackColor = True
        '
        'Button10A
        '
        Me.Button10A.Image = Global.Majime.My.Resources.Resources.accept
        Me.Button10A.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button10A.Location = New System.Drawing.Point(473, 246)
        Me.Button10A.Name = "Button10A"
        Me.Button10A.Size = New System.Drawing.Size(120, 31)
        Me.Button10A.TabIndex = 46
        Me.Button10A.Text = "     Confirmar Check In"
        Me.Button10A.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button10A.UseVisualStyleBackColor = True
        '
        'Button9A
        '
        Me.Button9A.Image = Global.Majime.My.Resources.Resources.cancel16
        Me.Button9A.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button9A.Location = New System.Drawing.Point(473, 289)
        Me.Button9A.Name = "Button9A"
        Me.Button9A.Size = New System.Drawing.Size(120, 30)
        Me.Button9A.TabIndex = 49
        Me.Button9A.Text = "Salir de la Sesión"
        Me.Button9A.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button9A.UseVisualStyleBackColor = True
        '
        'Button7A
        '
        Me.Button7A.Image = Global.Majime.My.Resources.Resources.basket_put
        Me.Button7A.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button7A.Location = New System.Drawing.Point(473, 200)
        Me.Button7A.Name = "Button7A"
        Me.Button7A.Size = New System.Drawing.Size(120, 31)
        Me.Button7A.TabIndex = 45
        Me.Button7A.Text = "Realizar Pagos"
        Me.Button7A.UseVisualStyleBackColor = True
        '
        'Button8A
        '
        Me.Button8A.Image = CType(resources.GetObject("Button8A.Image"), System.Drawing.Image)
        Me.Button8A.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button8A.Location = New System.Drawing.Point(221, 288)
        Me.Button8A.Name = "Button8A"
        Me.Button8A.Size = New System.Drawing.Size(120, 31)
        Me.Button8A.TabIndex = 41
        Me.Button8A.Text = "Ver Habitaciones"
        Me.Button8A.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button8A.UseVisualStyleBackColor = True
        '
        'Button6A
        '
        Me.Button6A.Image = Global.Majime.My.Resources.Resources.add1
        Me.Button6A.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button6A.Location = New System.Drawing.Point(347, 160)
        Me.Button6A.Name = "Button6A"
        Me.Button6A.Size = New System.Drawing.Size(120, 31)
        Me.Button6A.TabIndex = 44
        Me.Button6A.Text = "  Agregar Reserva"
        Me.Button6A.UseVisualStyleBackColor = True
        '
        'Button5A
        '
        Me.Button5A.Image = CType(resources.GetObject("Button5A.Image"), System.Drawing.Image)
        Me.Button5A.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button5A.Location = New System.Drawing.Point(221, 160)
        Me.Button5A.Name = "Button5A"
        Me.Button5A.Size = New System.Drawing.Size(120, 31)
        Me.Button5A.TabIndex = 40
        Me.Button5A.Text = "Ver Reserva"
        Me.Button5A.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button5A.UseVisualStyleBackColor = True
        '
        'Button4A
        '
        Me.Button4A.Image = CType(resources.GetObject("Button4A.Image"), System.Drawing.Image)
        Me.Button4A.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4A.Location = New System.Drawing.Point(347, 242)
        Me.Button4A.Name = "Button4A"
        Me.Button4A.Size = New System.Drawing.Size(120, 31)
        Me.Button4A.TabIndex = 43
        Me.Button4A.Text = "  Agregar Mascota"
        Me.Button4A.UseVisualStyleBackColor = True
        '
        'Button3A
        '
        Me.Button3A.Image = CType(resources.GetObject("Button3A.Image"), System.Drawing.Image)
        Me.Button3A.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button3A.Location = New System.Drawing.Point(221, 242)
        Me.Button3A.Name = "Button3A"
        Me.Button3A.Size = New System.Drawing.Size(120, 31)
        Me.Button3A.TabIndex = 39
        Me.Button3A.Text = "Ver Mascota"
        Me.Button3A.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button3A.UseVisualStyleBackColor = True
        '
        'Button2A
        '
        Me.Button2A.Image = Global.Majime.My.Resources.Resources.add1
        Me.Button2A.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button2A.Location = New System.Drawing.Point(347, 200)
        Me.Button2A.Name = "Button2A"
        Me.Button2A.Size = New System.Drawing.Size(120, 31)
        Me.Button2A.TabIndex = 42
        Me.Button2A.Text = "Agregar Cliente"
        Me.Button2A.UseVisualStyleBackColor = True
        '
        'Button1A
        '
        Me.Button1A.Image = CType(resources.GetObject("Button1A.Image"), System.Drawing.Image)
        Me.Button1A.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1A.Location = New System.Drawing.Point(221, 200)
        Me.Button1A.Name = "Button1A"
        Me.Button1A.Size = New System.Drawing.Size(120, 31)
        Me.Button1A.TabIndex = 38
        Me.Button1A.Text = "Ver Cliente"
        Me.Button1A.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button1A.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Goudy Old Style", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(251, 66)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(305, 40)
        Me.Label2.TabIndex = 75
        Me.Label2.Text = "MENÚ PRINCIPAL"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Controls.Add(Me.Button1A)
        Me.Panel1.Controls.Add(Me.Button12A)
        Me.Panel1.Controls.Add(Me.Button2A)
        Me.Panel1.Controls.Add(Me.btnFoto1)
        Me.Panel1.Controls.Add(Me.Button3A)
        Me.Panel1.Controls.Add(Me.Button10A)
        Me.Panel1.Controls.Add(Me.Button4A)
        Me.Panel1.Controls.Add(Me.Button9A)
        Me.Panel1.Controls.Add(Me.Button5A)
        Me.Panel1.Controls.Add(Me.Button7A)
        Me.Panel1.Controls.Add(Me.Button6A)
        Me.Panel1.Controls.Add(Me.Button8A)
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(816, 498)
        Me.Panel1.TabIndex = 76
        '
        'MainOficinista
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.BackgroundImage = Global.Majime.My.Resources.Resources.html_color_codes_color_tutorials_hero_00e10b1f
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(800, 459)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "MainOficinista"
        Me.Text = "MainOficinista"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button12A As Button
    Friend WithEvents btnFoto1 As Button
    Friend WithEvents Button10A As Button
    Friend WithEvents Button9A As Button
    Friend WithEvents Button7A As Button
    Friend WithEvents Button8A As Button
    Friend WithEvents Button6A As Button
    Friend WithEvents Button5A As Button
    Friend WithEvents Button4A As Button
    Friend WithEvents Button3A As Button
    Friend WithEvents Button2A As Button
    Friend WithEvents Button1A As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel1 As Panel
End Class
